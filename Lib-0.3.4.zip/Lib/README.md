# Personal-Python-Module(Lib)

<p align="center">
<img src="https://img.shields.io/github/last-commit/BhJaipal/Personal-Python-Module">
<img src="https://img.shields.io/github/contributors/BhJaipal/Personal-Python-Module">
</p>

> Check [Lib.__init__](https://github.com/BhJaipal/Personal-python-module/blob/main/Lib/__init__.py)
> 
> Open [Lib.main](https://github.com/BhJaipal/Personal-python-module/blob/main/Lib/main.py) for functions of Personal-Python-Module
> 
> [Lib.setup](https://github.com/BhJaipal/Personal-python-module/blob/main/Lib/setup.py)
> 
> [Documentation](https://github.com/BhJaipal/Personal-python-module/blob/main/Lib/Main_doc.ipynb) for main in Jupyter notebook
> 
> [Documentation](https://github.com/BhJaipal/Personal-python-module/blob/main/Lib/Main_doc.md) for main

## Lib.__init__
> __init__
> 
> new
> 
> name
> 
> __doc__

## Lib.main

| new_math |matrix | notation |
|-------|----------|---------|
| round | matrix | prefix |
| cbrt | mat_trans | postfix |
| logadd | determin   |       |
| logsub |     |       |

## Lib.setup

This is setup file

# About
> This is a Personal python module created by Jaipal Bhanwariya.
> To access it as a module, save it your python library folder.
> Then open interpreter and import this file.